
 _G.WhitelistedHWIDs = {
    "d85b26ff06724c7e236c23d9f5e13a3fb8a2b3498d4098334f30aa7ac454bbb535a9b5ba2a519e6a9e44559b5b38a21de0935809705ebf031ae92f4d6b77337f",
    "",
    "",
}
