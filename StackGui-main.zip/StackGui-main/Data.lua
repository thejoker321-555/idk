_G.VersionInfo = "Version 1.1.1"
_G.update = false
_G.DataLoaded = false
_G.ExecutionLogs = false
_G.SDown = false
_G.KickMessage = "You have been kicked from the game "
_G.KickData = "Reason : Down For maintenance."
_G.UpdateHrs = ""
